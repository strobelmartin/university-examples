#include <iostream>
#include <fstream>
#include "matrix.h"
using namespace std;
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
/*
 * Saving of matrix ( instance of class Matrix ) into project folder.
 * Asking for number of rows and columns and if we want create the dense matrix, than loading new
 * matrix from standard input, otherwise if we want create the sparse matrix, than first will be
 * the matrix filled by all zeros and than the user can set arbitrarily elements. After typing
 * the name of matrix, it will be saved in the main folder.
 */
void       SaveMatrix      ( void )
 {
   char     name [ 50 ], choise;
   int      rows, cols;
   Matrix * m;

   cout << "What type of matrix do you want save?"   << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Dense matrix                  *" << endl;
   cout << "*  1 .. Sparse matrix                 *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   cin >> choise;
   switch ( choise )
    {
      case '0':
         cout << "Type number of rows of the matrix you want save: ";
         cin  >> rows;
         cout << "Type number of columns of the matrix you want save: ";
         cin  >> cols;
         cout << "Please, write the " << rows << "x" << cols << " matrix you want save:" << endl;
         m = new Matrix ( rows, cols );
         break;

      case '1':
         cout << "Type number of rows of the matrix you want save: ";
         cin  >> rows;
         cout << "Type number of columns of the matrix you want save: ";
         cin  >> cols;
         m = new Matrix ( rows, cols, true );
         m -> SetElems ();
         break;

      default : cout << "Error: Unvalid choise." << endl; return;
    }

   cout << "Now, type the name of matrix you want save: ";
   cin  >> name;
   
   if ( m -> Save ( name ) )
      cout << "Matrix successfully saved." << endl;
   
   delete m;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Checking if matrix ( instance of class Matrix ) exists in project folder.
 * Returns TRUE if the file with <@param fileName> exists in the main folder,
 * otherwise returns FALSE.
 */
bool       IsValid         ( const char * fileName )
 {
   ifstream inFile ( fileName );
   return inFile;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Printing of matrix ( instance of class Matrix ) from project folder.
 * Asking for the name of matrix and checking if it's valid. If so, the matrix will be loaded from 
 * the input file and printed to output.
 */
void       PrintMatrix     ( void )
 {
   char name [ 50 ];
   
   cout << "Type the name of matrix you want print: ";
   cin  >> name;
   
   if ( ! IsValid ( name ) )
    {
      cout << "Error: Matrix with name '" << name << "' has not been found." << endl;
    }
   else
    {
      Matrix * m = new Matrix ( name );
      cout << *m;
      delete m;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * Deleting of matrix ( instance of class Matrix ) from project folder.
 * Asking for the name of matrix and checking if it's valid. If so, the matrix will be deleted from 
 * the project folder, otherwise it will be displayed a warning message.
 */
void       DelMatrix       ( void )
 {
   char name [ 50 ];
   
   cout << "Type the name of matrix you want delete: ";
   cin  >> name;
   
   if ( remove ( name ) )
      cout << "Error: Matrix with name '" << name << "' has not been found." << endl;
   else
      cout << "Matrix successfully deleted." << endl;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Saving of result matrix ( instance of class Matrix ) into project folder.
 * Asking to choise between save the result matrix or not, if so, follows typing the name of
 * matrix you want save and than it will be saved in the project folder.
 */
void       SaveResult      ( Matrix * src )
 {
   char name [ 50 ];
   char choise;

   cout << "Do you want save the result matrix?" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  N .. Ne                            *" << endl;
   cout << "*  Y .. Ano                           *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   cin >> choise;
   switch ( choise )
    {
      case 'N': return;
      case 'Y': break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }
   
   cout << "Now, type the name of matrix you want save: ";
   cin  >> name;
   
   if ( src -> Save ( name ) )
      cout << "Matrix successfully saved." << endl;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Reading (creating) of matrix ( instance of class Matrix ) from stdin.
 * Asking for number of rows and columns, than loading new matrix from standard input and 
 * returning the pointer of created instance of class Matrix.
 */
Matrix *   ReadMatrix      ( void )
 {
   int  rows, cols;

   cout << "Type number of rows of the matrix you want enter: ";
   cin  >> rows;
   
   cout << "Type number of columns of the matrix you want enter: ";
   cin  >> cols;

   cout << "Please, write the " << rows << "x" << cols << " matrix you want enter:" << endl;
   Matrix * m = new Matrix ( rows, cols );
   
   return m;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Loading of matrix ( instance of class Matrix ) from project folder.
 * Asking for the name of matrix and checking if it's valid. If so, the matrix will be loaded from 
 * the input file and pointer on this matrix will be returned, otherwise will be returned NULLp.
 */
Matrix *   LoadMatrix      ( void )
 {
   char name [ 50 ];
   Matrix * m = NULL;
   
   cout << "Type the name of matrix you want load: ";
   cin  >> name;
   
   if ( ! IsValid ( name ) )
    {
      cout << "Error: Matrix with name '" << name << "' has not been found." << endl;
    }
   else
    {
      m = new Matrix ( name );
      cout << "Matrix successfully loaded." << endl;
    }
   
   return m;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Addition of two matrices ( instances of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. Then checks, if both matrices have the same size and if so, it will be calculated the
 * result and printed to the standard output. After we are asked to save the result or not.
 */
void       SumMatrix       ( void )
 {
   char choise;
   Matrix * x, * y, * res;

   cout << "First matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading first matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   cout << "Second matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading second matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': y = LoadMatrix (); break;
      case '1': y = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! y ) return;
   
   if ( x -> GetRows () != y -> GetRows () || x -> GetCols () != y -> GetCols () )
    {
      cout << "Cannot calculate: matrices have different sizes." << endl;
      delete x;
      delete y;
    }
   else
    {
      res = (*x) + (*y);
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*        RESULT OF CALCULATION        *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << *res;
      SaveResult ( res );
      delete x;
      delete y;
      delete res;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * Difference of two matrices ( instances of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. Then checks, if both matrices have the same size and if so, it will be calculated the
 * result and printed to the standard output. After we are asked to save the result or not.
 */
void       DiffMatrix      ( void )
 {
   char choise;
   Matrix * x, * y, * res;

   cout << "First matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading first matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   cout << "Second matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading second matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': y = LoadMatrix (); break;
      case '1': y = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! y ) return;
   
   if ( x -> GetRows () != y -> GetRows () || x -> GetCols () != y -> GetCols () )
    {
      cout << "Cannot calculate: matrices have different sizes." << endl;
      delete x;
      delete y;
    }
   else
    {
      res = (*x) - (*y);
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*        RESULT OF CALCULATION        *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << *res;
      SaveResult ( res );
      delete x;
      delete y;
      delete res;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * Multiplied of two matrices ( instances of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. Then checks, if number of columns of first matrix is equal to number of rows of second
 * matrix and if so, it will be calculated the result and printed to the standard output.
 * After we are asked to save the result or not.
 */
void       MulMatrix       ( void )
 {
   char choise;
   Matrix * x, * y, * res;

   cout << "First matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading first matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   cout << "Second matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading second matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': y = LoadMatrix (); break;
      case '1': y = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! y ) return;
   
   if ( x -> GetCols () != y -> GetRows () )
    {
      cout << "Cannot calculate: width of 1st matrix isn't equal to height of 2nd matrix." << endl;
      delete x;
      delete y;
    }
   else
    {
      res = (*x) * (*y);
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*        RESULT OF CALCULATION        *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << *res;
      SaveResult ( res );
      delete x;
      delete y;
      delete res;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * Transposition of matrix ( instance of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. Than it will be calculated the result and printed to the standard output.
 * After we are asked to save the result or not.
 */
void       TranspMatrix    ( void )
 {
   char choise;
   Matrix * x, * res;

   cout << "Entering matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading the matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }
   
   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   res = x -> Transp ();
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*        RESULT OF CALCULATION        *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << *res;
   SaveResult ( res );
   delete x;
   delete res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Inversion of matrix ( instance of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. After that it checks if the matrix has number of rows equal to the number of columns.
 * If so (square shaped), it will be calculated the result and printed to the standard output.
 * After we are asked to save the result or not.
 */
void       InvMatrix       ( void )
 {
   char choise;
   Matrix * x, * res;

   cout << "Entering matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading the matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   if ( x -> GetRows () != x -> GetCols () )
    {
      cout << "Cannot calculate: matrix isn't square shaped." << endl;
      delete x;
    }
   else
    {
      res = x -> Invers ();
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*        RESULT OF CALCULATION        *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << *res;
      SaveResult ( res );
      delete x;
      delete res;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * Determinant and rank of matrix ( instance of class Matrix ).
 * First it askes, if the matrices should be loaded from file in project folder or from standard
 * input. Than it will be calculated the determinant, rank and both will be printed to the standard
 * output. If the matrix isn't square shaped, the determinant is equal to zero.
 */
void       DetRankMatrix   ( void )
 {
   char     choise;
   double   res;
   Matrix * x;

   cout << "Entering matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading the matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*        RESULT OF CALCULATION        *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   res = x -> Determ ();
   cout << "Determinant: " << res << endl;
   res = x -> Rank ();
   cout << "Rank:        " << res << endl;
   
   delete x;
 }
//--------------------------------------------------------------------------------------------------
/*
 * Gauss elimination method for matrix ( instance of class Matrix ).
 * First it askes, if the matrix should be loaded from file in project folder or from standard
 * input. Than it will be created a copy of this matrix (because we don't want change the same
 * matrix and this copy will be converted to Upper triangular form, than to Lower triangular form
 * and now on the diagonal are same ones and in the last column are the results. We are asked if
 * we want comment and print partial steps of elimination.
 * After we are asked to save the result or not.
 */
void       GemMatrix       ( void )
 {
   char choise;
   Matrix * x, * res;

   cout << "Entering matrix:" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  0 .. Nacist ulozenou matici        *" << endl;
   cout << "*  1 .. Zadat novou matici            *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for loading the matrix from file or writing new matrix. */
   cin >> choise;
   switch ( choise )
    {
      case '0': x = LoadMatrix (); break;
      case '1': x = ReadMatrix (); break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }

   /* Matrix has not been found during the loading and LoadMatrix () returned NULL pointer */
   if ( ! x ) return;
   
   res = new Matrix ( * x );

   cout << "Do you want comment partial steps?" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*  N .. Ne                            *" << endl;
   cout << "*  Y .. Ano                           *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
   /* Selecting for printing and commenting partial steps of elemination or not. */
   cin >> choise;
   switch ( choise )
    {
      case 'N':
         *res = x -> UppTriForm ( false );
         *res = x -> LowTriForm ( false );
         break;
      case 'Y':
         *res = x -> UppTriForm ( true );
         *res = x -> LowTriForm ( true );
         break;
      default : cout << "Error: Unvalid choise." << endl; return;
    }
   
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << "*        RESULT OF CALCULATION        *" << endl;
   cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   cout << *res;
   SaveResult ( res );
   delete x;
   delete res;
 }
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
int        main            ( int argc, char * argv [] )
 {
   bool quit = false;
   char choise;

   while ( ! quit )
    {
      /* Main menu of the program ( in CZE ). */
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*         MATICOVA KALKULACKA         *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*  0 .. Ulozit matici                 *" << endl;
      cout << "*  1 .. Vypsat ulozenou matici        *" << endl;
      cout << "*  2 .. Smazat ulozenou matici        *" << endl;
      cout << "*  3 .. Scitani matic                 *" << endl;
      cout << "*  4 .. Odecitani matic               *" << endl;
      cout << "*  5 .. Nasobeni matic                *" << endl;
      cout << "*  6 .. Transpozice matice            *" << endl;
      cout << "*  7 .. Inverzni matice               *" << endl;
      cout << "*  8 .. Determinant a hodnost matice  *" << endl;
      cout << "*  9 .. Gaussova eliminacni metoda    *" << endl;
      cout << "*  Q .. Konec programu                *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
   
      /* Selecting choise from the menu, picks first charackter. */
      cin >> choise;
      switch ( choise )
       {
         case '0': SaveMatrix ();    break;
         case '1': PrintMatrix ();   break;
         case '2': DelMatrix ();     break;
         case '3': SumMatrix ();     break;
         case '4': DiffMatrix ();    break;
         case '5': MulMatrix ();     break;
         case '6': TranspMatrix ();  break;
         case '7': InvMatrix ();     break;
         case '8': DetRankMatrix (); break;
         case '9': GemMatrix ();     break;
         case 'Q': return 0;
         default : cout << "Error: Unvalid choise." << endl; break;
       }
      
      /* Selecting for continue or terminate the program. */
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      cout << "*  0 .. Pokracovat                    *" << endl;
      cout << "*  Q .. Konec programu                *" << endl;
      cout << "* * * * * * * * * * * * * * * * * * * *" << endl;
      
      cin >> choise;
      switch ( choise )
       {
         case '0': break;
         case 'Q': quit = true; break;
       }
    }
   
   return 0;
 }


