#ifndef __MATRIX_H__
#define __MATRIX_H__

using namespace std;


class Matrix
 {
   public:
                           Matrix                ( void );
                           Matrix                ( int rows, int cols, bool empty = false );
                           Matrix                ( const char * fileName );
                           Matrix                ( const Matrix & src );
                         ~ Matrix                ( void );
      Matrix             & operator =            ( const Matrix & src );
      Matrix             * operator +            ( const Matrix & src ) const;
      Matrix             * operator -            ( const Matrix & src ) const;
      Matrix             * operator *            ( const Matrix & src ) const;
      friend ostream     & operator <<           ( ostream & os, const Matrix & src );
      Matrix             & UppTriForm            ( double & coeff );
      Matrix             & UppTriForm            ( bool comments = false );
      Matrix             & LowTriForm            ( bool comments = false );
      Matrix             * Transp                ( void ) const;
      Matrix             * Invers                ( void ) const;
      double               Determ                ( void ) const;
      double               Rank                  ( void ) const;
      int                  GetRows               ( void ) const;
      int                  GetCols               ( void ) const;
      void                 SetElems              ( void );
      bool                 Save                  ( const char * fileName ) const;
   
   protected:
      double            ** m_Data;
      int                  m_Rows;
      int                  m_Cols;
 };


#endif /* __MATRIX_H__ */


