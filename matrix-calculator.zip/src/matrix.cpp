#include <iostream>
#include <fstream>
#include <iomanip>
#include "matrix.h"
using namespace std;
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
/*
 * IMPLICIT CONSTRUCTOR
 * Creates an empty instance of class Matrix represented by number zero. Number of rows and columns
 * are set to one and is allocated memory for just one number -> the representing zero.
 */
                           Matrix :: Matrix      ( void )
 {
   m_Rows = m_Cols   = 1;   
   m_Data            = new double* [ m_Rows ];
   m_Data [ 0 ]      = new double  [ m_Cols ];
   m_Data [ 0 ][ 0 ] = 0;
 }
//--------------------------------------------------------------------------------------------------
/*
 * CONSTRUCTOR
 * Creates an instance of class Matrix of <@param rows> rows and <@param cols> columns.
 * If <@param empty> is false (implicit), allocates the array and loades the data from the stdin.
 * If <@param empty> is changed to true, allocates the array and matrix are empty - all zeros.
 */
                	         Matrix :: Matrix      ( int rows, int cols, bool empty )
 {
   int i, j;
   
   m_Rows = rows;
   m_Cols = cols;
   
   m_Data = new double* [ m_Rows ];
   for ( i = 0 ; i < m_Rows ; i ++ )
      m_Data [ i ] = new double [ m_Cols ];
   
   if ( ! empty )
    {
      for ( i = 0 ; i < m_Rows ; i ++ )
         for ( j = 0 ; j < m_Cols ; j ++ )
            cin >> m_Data [ i ][ j ];
    }
   else
    {
      for ( i = 0 ; i < m_Rows ; i ++ )
         for ( j = 0 ; j < m_Cols ; j ++ )
            m_Data [ i ][ j ] = 0;
    }
 }
//--------------------------------------------------------------------------------------------------
/*
 * CONSTRUCTOR
 * Opens input file with <@param fileName> located in project folder, counts number of columns
 * and rows of matrix in it and create an instance of class Matrix with these parameters and
 * data from the file.
 */
                	         Matrix :: Matrix      ( const char * fileName )
 {
   ifstream inFile ( fileName );
   string line;
   m_Rows = m_Cols = 0;
   int i = 0, j;

   /* Finding number of comlumns using cutting line and counting number of spaces + 1 ( at end ) */
   getline ( inFile, line );
   while ( line [ i ] != '\0' )
    {
      if ( line [ i ] == ' ' )
         m_Cols ++;
      i ++;
    }
   m_Cols ++;
   
   /* 
    * Finding number of rows using counting number of lines in file + 1 ( one line cutted for
    * finding number of columns.
    */
   while ( getline ( inFile, line ) )
      m_Rows ++;
   m_Rows ++;

   /* Data from the file has been extracted, so we must close the file and repeat the opening */
   inFile . close ();
   inFile . open ( fileName );
   
   /* 
    * Alocating of needed place and storing the data from input file to new matrix
    * (instance of class Matrix).
    */
   m_Data = new double* [ m_Rows ];
   for ( i = 0 ; i < m_Rows ; i ++ )
      m_Data [ i ] = new double [ m_Cols ];
   
   for ( i = 0 ; i < m_Rows ; i ++ )
      for ( j = 0 ; j < m_Cols ; j ++ )
         inFile >> skipws >> m_Data [ i ][ j ];
 }
//--------------------------------------------------------------------------------------------------
/*
 * COPY CONSTRUCTOR
 * Creates an instance of class Matrix copying from the instance <param@ src>.
 * Allocates the array for data and loades the data from the instance <param@ src>.
 */
                	         Matrix :: Matrix      ( const Matrix & src )
 {
   int i, j;
   
   m_Cols = src . m_Cols;
   m_Rows = src . m_Rows;
   
   m_Data = new double* [ m_Rows ];
   for ( i = 0 ; i < m_Rows ; i ++ )
      m_Data [ i ] = new double [ m_Cols ];
   
   for ( i = 0 ; i < m_Rows ; i ++ )
      for ( j = 0 ; j < m_Cols ; j ++ )
         m_Data [ i ][ j ] = src . m_Data [ i ][ j ];
 }
//--------------------------------------------------------------------------------------------------
/*
 * DESTRUCTOR
 * Deletes an instance of class Matrix.
 * Deallocates the array with data and set num of rows and columns to zero.
 */
                	         Matrix :: ~ Matrix    ( void )
 {
   for ( int i = 0 ; i < m_Rows ; i ++ )
      delete [] m_Data [ i ];
   delete [] m_Data;
   m_Rows = m_Cols = 0;
 }
//--------------------------------------------------------------------------------------------------
/*
 * OVERLOADED OPERATOR =
 * Creates an instance of class Matrix copying from the instance <param@ src>. If the source matrix
 * is same as the destination matrix, returns *this instance, otherwise deletes the destination
 * matrix and allocates the array for data and loades the data from the instance <param@ src>.
 */
      Matrix             & Matrix :: operator =  ( const Matrix & src )
 {
   if ( this == & src ) return * this;
   
   int i, j;
   
   for ( i = 0 ; i < m_Rows ; i ++ )
      delete [] m_Data [ i ];
   delete [] m_Data;
   m_Rows = m_Cols = 0;
   
   m_Cols = src . m_Cols;
   m_Rows = src . m_Rows;
   
   m_Data = new double* [ m_Rows ];
   for ( i = 0 ; i < m_Rows ; i ++ )
      m_Data [ i ] = new double [ m_Cols ];
   
   for ( i = 0 ; i < m_Rows ; i ++ )
      for ( j = 0 ; j < m_Cols ; j ++ )
         m_Data [ i ][ j ] = src . m_Data [ i ][ j ];
   
   return * this;
 }
//--------------------------------------------------------------------------------------------------
/*
 * OVERLOADED OPERATOR +
 * It creates auxiliary variable 'res' of type Matrix, which is the copy of instance *this.
 * To each element from 'res' is added appropriately element from Matrix 'src'. Method
 * returns pointer on variable 'res' - result matrix.
 */
      Matrix             * Matrix :: operator +  ( const Matrix & src ) const
 {
   Matrix * res = new Matrix ( * this );
   
   for ( int i = 0 ; i < m_Rows ; i ++ )
      for ( int j = 0 ; j < m_Cols ; j ++ )
         res -> m_Data [ i ][ j ] += src . m_Data [ i ][ j ];
   
   return res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * OVERLOADED OPERATOR -
 * It creates auxiliary variable 'res' of type Matrix, which is the copy of instance *this.
 * From each element from 'res' is deducted appropriately element from Matrix 'src'. Method
 * returns pointer on variable 'res' - result matrix.
 */
      Matrix             * Matrix :: operator -  ( const Matrix & src ) const
 {
   Matrix * res = new Matrix ( * this );
   
   for ( int i = 0 ; i < m_Rows ; i ++ )
      for ( int j = 0 ; j < m_Cols ; j ++ )
         res -> m_Data [ i ][ j ] -= src . m_Data [ i ][ j ];
   
   return res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * OVERLOADED OPERATOR *
 * It creates auxiliary variable 'res' of type Matrix, which has number of rows equal to number of
 * rows from matrix '*this' and number of columns equal to number of columns from matrix 'src'.
 * The result data (in the matrix 'res') are calculated according to the rules of matrix multiplied.
 * Method returns pointer on variable 'res' - result matrix.
 */
      Matrix             * Matrix :: operator *  ( const Matrix & src ) const
 {
   Matrix * res = new Matrix ( m_Rows, src . m_Cols, true );
   
   for ( int i = 0 ; i < m_Rows ; i ++ )
      for ( int j = 0 ; j < src . m_Cols ; j ++ )
         for ( int k = 0 ; k < m_Cols ; k ++ )
            res -> m_Data [ i ][ j ] += m_Data [ i ][ k ] * src . m_Data [ k ][ j ];
   
   return res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * OVERLOADED OPERATOR <<
 * Printing the data from matrix <@param src> into output stream <@param os>.
 * End of lines - '\n', Space between data - ' '.
 */
      ostream            & operator <<           ( ostream & os, const Matrix & src )
 {
   for ( int i = 0 ; i < src . m_Rows ; i ++ )
    {
      for ( int j = 0 ; j < src . m_Cols ; j ++ )
       {
         os << setw ( 6 ) << setprecision ( 2 ) << src . m_Data [ i ][ j ];
         if ( j != src . m_Cols - 1 )
            os << " ";
       }
      os << endl;
    }
   
   return os;
 }
//--------------------------------------------------------------------------------------------------
/*
 * UPPER TRIANGULAR FORM OF MATRIX
 * It creates the matrix to the form, where are all ones below the diagonal. First it deletes the
 * zeros on the diagonal by adding the first row from the top, which solves this problem. After
 * it's done, it creates all zeros below the diagonal and non-zero numbers on the diagonal
 * (if it's possible). Into the output parameter 'coeff' is stored the number representing the
 * value according to the rules of the changes performed during the elimination by GEM.
 * The method returns a reference to the changed original instance '*this'.
 */
      Matrix             & Matrix :: UppTriForm  ( double & coeff )
 {
   int    i, j, k, l, m, z = 1, br = 0;
   double x, diag, underdiag, deter = 1;

   /*
    * Deleting of the zeros on the diagonal.
    * If the zero is located on the diagonal, we will remove it by adding the first row from the
    * top. If we cant do it this way, it is a zero column.
    */
   for ( i = 0, j = 0 ; i < ( m_Rows < m_Cols ? m_Rows : m_Cols - 1 ) ; i ++, j ++ )
    {
      z = -1;
      
      while ( m_Data [ i ][ j ] == 0 )
       {
         if ( m_Data [ 1 + z ][ j ] != 0 )
          {
            for ( k = 0 ; k < m_Cols ; k ++ )
               m_Data [ i ][ k ] = m_Data [ 1 + z ][ k ] + m_Data [ i ][ k ];
            break;
          }
         if ( z + 1 == m_Rows - 1 ) break;
         z ++;
       }
    }
   
   /*
    * Creating all zeros under the diagonal and
    * non-zero numbers on the diagonal ( if it's possible ).
    */
   for ( i = 0, j = 0 ; i < ( m_Rows < m_Cols ? m_Rows : m_Cols - 1 ) ; i ++, j ++ )
    {
      br = 0;
      z = 1;

      /*
       * If the zero is located on the diagonal, we will remove it by adding the first row which
       * solves this problem. It can be attributed only the rows that are located below the row
       * of current element of diagonal.
       */
      while ( m_Data [ i ][ j ] == 0 )
       {
         if ( i == m_Rows - 1 ) break;
      
         if ( m_Data [ i + z ][ j ] != 0 )
          {
            for ( k = 0 ; k < m_Cols ; k ++ )
             {
               x = m_Data [ i ][ k ];
               m_Data [ i ][ k ] = m_Data [ i + z ][ k ];
               m_Data [ i + z ][ k ] = x;
             }

            deter *= -1;
            break;
          }
       
         if ( z + i == m_Rows - 1 )
          {
            br = 1;
            break;
          }
      
         z++;
       }
     
      if ( br == 1 ) continue;
      
      /* Creating all zeros below the current (actual) element of the diagonal. */
      diag = m_Data [ i ][ j ];
      for ( l = i + 1 ; l < m_Rows ; l ++ )
       {
         underdiag = m_Data [ l ][ j ];
         if ( underdiag == 0 ) continue;

         for ( m = 0 ; m < m_Cols ; m ++ )
          {
            m_Data [ l ][ m ] *= diag;
            m_Data [ l ][ m ] = m_Data [ l ][ m ] / underdiag;
            m_Data [ l ][ m ] = m_Data [ l ][ m ] - m_Data [ i ][ m ];
            
            /*
             * If the number is a number very closed to the zero, takes it as zero.
             * (0.000001 - positive zero, -0.000001 - negative zero)
             */
            if ( m_Data [ l ][ m ] > -0.000001 && m_Data [ l ][ m ] < 0.000001 )
               m_Data [ l ][ m ] = 0;

            if ( m == m_Cols - 1 )
             {
               deter *= underdiag;
               deter /= diag;
             }
          }
       }
    }
   
   coeff = deter;
   return * this;
 }
//--------------------------------------------------------------------------------------------------
/*
 * UPPER TRIANGULAR FORM OF MATRIX
 * It creates the matrix to the form, where are all ones below the diagonal. First comes deleting
 * of the zeros on the diagonal by adding the first row from the top, which solves this problem.
 * After it's done, it creates all zeros below the diagonal and non-zero numbers on the diagonal
 * (if it's possible). We are asked if we want comment and print partial steps <param @comments>.
 * The method returns a reference to the changed original instance '*this'.
 */
      Matrix             & Matrix :: UppTriForm  ( bool comments )
 {
   int    i, j, k, l, m, z = 1, br = 0;
   double x, diag, underdiag, deter = 1;
   char   choise;

   if ( comments )
    {
      cout << "/*-----------------------------COMMENTARY-----------------------------*/" << endl;
      cout << "Input matrix:" << endl;
      cout << *this;
      cout << "Please enter any key to continue: ";
      cin  >> choise;
    }
   
   /*
    * Deleting of the zeros on the diagonal.
    * If the zero is located on the diagonal, we will remove it by adding the first row from the
    * top. If we cant do it this way, it is a zero column.
    */
   for ( i = 0, j = 0 ; i < ( m_Rows < m_Cols ? m_Rows : m_Cols - 1 ) ; i ++, j ++ )
    {
      z = -1;
      
      while ( m_Data [ i ][ j ] == 0 )
       {
         if ( m_Data [ 1 + z ][ j ] != 0 )
          {
            for ( k = 0 ; k < m_Cols ; k ++ )
               m_Data [ i ][ k ] = m_Data [ 1 + z ][ k ] + m_Data [ i ][ k ];
               
            if ( comments )
             {
               cout << "/*-----------------------------COMMENTARY"
                    << "-----------------------------*/" << endl;
               cout << "Deleting the zero on the main diagonal"
                    << " - element [ " << i + 1 << " ][ " << j + 1 << " ]" << endl << "   "
                    << "> Row nr. " << i + 1 << " + row nr. " << i + z + 1 << " => row nr. "
                    << i + 1 << endl;
               cout << endl << *this;
               cout << "Please enter any key to continue: ";
               cin  >> choise;
             }
             
            break;
          }
         if ( z + 1 == m_Rows - 1 ) break;
         z ++;
       }
    }

   /*
    * Creating all zeros under the diagonal and
    * non-zero numbers on the diagonal ( if it's possible ).
    */   
   for ( i = 0, j = 0 ; i < ( m_Rows < m_Cols ? m_Rows : m_Cols - 1 ) ; i ++, j ++ )
    {
      br = 0;
      z = 1;
   
      /*
       * If the zero is located on the diagonal, we will remove it by adding the first row which
       * solves this problem. It can be attributed only the rows that are located below the row
       * of current element of diagonal.
       */
      while ( m_Data [ i ][ j ] == 0 )
       {
         if ( i == m_Rows - 1 ) break;
      
         if ( m_Data [ i + z ][ j ] != 0 )
          {
            for ( k = 0 ; k < m_Cols ; k ++ )
             {
               x = m_Data [ i ][ k ];
               m_Data [ i ][ k ] = m_Data [ i + z ][ k ];
               m_Data [ i + z ][ k ] = x;
             }

            if ( comments && k == m_Cols - 1 )
             {
               cout << "/*-----------------------------COMMENTARY"
                    << "-----------------------------*/" << endl;
               cout << "Deleting the zero on the main diagonal"
                    << " - element [ " << i + 1 << " ][ " << j + 1 << " ]" << endl << "   "
                    << "> Swap row nr. " << i + 1 << " with row nr. " << i + z + 1 << endl;
               cout << endl << *this;
               cout << "Please enter any key to continue: ";
               cin  >> choise;
             }

            deter *= -1;
            break;
          }
       
         if ( z + i == m_Rows - 1 )
          {
            br = 1;
            break;
          }
      
         z++;
       }
     
      if ( br == 1 ) continue;

      /* Creating all zeros below the current (actual) element of the diagonal. */
      diag = m_Data [ i ][ j ];
      for ( l = i + 1 ; l < m_Rows ; l ++ )
       {
         underdiag = m_Data [ l ][ j ];
         if ( underdiag == 0 ) continue;

         for ( m = 0 ; m < m_Cols ; m ++ )
          {
            m_Data [ l ][ m ] *= diag;
            m_Data [ l ][ m ] = m_Data [ l ][ m ] / underdiag;
            m_Data [ l ][ m ] = m_Data [ l ][ m ] - m_Data [ i ][ m ];

            /*
             * If the number is a number very closed to the zero, takes it as zero.
             * (0.000001 - positive zero, -0.000001 - negative zero)
             */
            if ( m_Data [ l ][ m ] > -0.000001 && m_Data [ l ][ m ] < 0.000001 )
               m_Data [ l ][ m ] = 0;

            if ( m == m_Cols - 1 )
             {
               deter *= underdiag;
               deter /= diag;
             }
         
            if ( comments && m == m_Cols - 1 )
             {
               cout << "/*-----------------------------COMMENTARY"
                    << "-----------------------------*/" << endl;
               cout << "Creating (reseting) the zero on the element [ " << l + 1 << " ][ " << j + 1
                    << " ] ( Nr. " << underdiag << " )" << endl
                    << "   > Row nr. " << l + 1 << " divided by this element ( Nr. " << underdiag
                    << " )" << endl
                    << "   > Row nr. " << l + 1 << " multiplied by element [ " << i + 1 << " ][ "
                    << j + 1 << " ] ( Nr. " << diag << " )" << endl << "   "
                    << "  (located on the main diagonal and above the element we reset)" << endl
                    << "   > Row nr. " << l + 1 << " - row nr. " << i + 1 << " => row nr. "
                    << l + 1 << endl;
               cout << endl << *this;
               cout << "Please enter any key to continue: ";
               cin  >> choise;
             }
          }
       }
    }
   
   return * this;
 }
//--------------------------------------------------------------------------------------------------
/*
 * LOWER TRIANGULAR FORM OF MATRIX
 * It creates the matrix to the form, where are all ones above the diagonal. It creates all zeros
 * above the diagonal and non-zero numbers on the diagonal (if it's possible).
 * We are asked if we want comment and print partial steps <param @comments>.
 * The method returns a reference to the changed original instance '*this'.
 */
      Matrix             & Matrix :: LowTriForm  ( bool comments )
 {
   int    i, j, k, l, m;
   double diag, poddiag;
   char   choise;

   /*
    * Creating all zeros above the diagonal and
    * non-zero numbers on the diagonal ( if it's possible ).
    */   
   for ( i = ( m_Rows < m_Cols ? m_Rows - 1 : m_Cols - 2 ), j = i ; i >= 0 ; i --, j -- )
    {
      /* Creating all zeros above the current element of the diagonal, if it's non-zero. */
      if ( ( diag = m_Data [ i ][ j ] ) != 0 )
       {
         for ( k = i - 1 ; k >= 0 ; k -- )
          {
            poddiag = m_Data [ k ][ j ];
            
            if ( poddiag == 0 ) continue;
            
            for ( l = m_Cols - 1 ; l >= 0 ; l -- )
             {
               m_Data [ k ][ l ] *= diag;
               m_Data [ k ][ l ] = m_Data [ k ][ l ] / poddiag;
               m_Data [ k ][ l ] = m_Data [ k ][ l ] - m_Data [ i ][ l ];

               /*
                * If the number is a number very closed to the zero, takes it as zero.
                * (0.000001 - positive zero, -0.000001 - negative zero)
                */
               if ( m_Data [ k ][ l ] > -0.000001 && m_Data [ k ][ l ] < 0.000001 )
                  m_Data [ k ][ l ] = 0;

               if ( comments && l == 0 )
                {
                  cout << "/*-----------------------------COMMENTARY"
                       << "-----------------------------*/" << endl;
                  cout << "Creating (reseting) the zero on the element [ " << k + 1 << " ][ "
                       << j + 1 << " ] ( Nr. " << poddiag << " )" << endl
                       << "   > Row nr. " << k + 1 << " divided by this element ( Nr. "
                       << poddiag << " )" << endl
                       << "   > Row nr. " << k + 1 << " multiplied by element [ " << i + 1
                       << " ][ " << j + 1 << " ] ( Nr. " << diag << " )" << endl << "   "
                       << "  (located on the main diagonal and under the element we reset)" << endl
                       << "   > Row nr. " << k + 1 << " - row nr. " << i + 1 << " => row nr. "
                       << k + 1 << endl;
                  cout << endl << *this;
                  cout << "Please enter any key to continue: ";
                  cin  >> choise;
                }
             }
          }

         /* 
          * Each element of the whole row will be divided by the element on the diagonal (of the
          * corresponding row) to get the one (1) to the diagonal.
          */
         if ( m_Data [ i ][ j ] != 0 && m_Data [ i ][ j ] != 1 )
          {
            for ( m = j ; m < m_Cols ; m ++ )
             {
               m_Data [ i ][ m ] /= diag;

               if ( m_Data [ i ][ m ] > -0.000001 && m_Data [ i ][ m ] < 0.000001 )
                  m_Data [ i ][ m ] = 0;
             }

            if ( comments )
             {
               cout << "/*-----------------------------COMMENTARY"
                    << "-----------------------------*/" << endl;
               cout << "Creating the one on the element [ " << i + 1 << " ][ " << j + 1 << " ]"
                    << endl << "   "
                    << "> Row nr. " << i + 1 << " divided by this element" << endl
                    << "     (the position where we want get the one)" << endl;
               cout << endl << *this;
               cout << "Please enter any key to continue: ";
               cin  >> choise;
             }
          }
       }
    }
   
   return * this;
 }
//--------------------------------------------------------------------------------------------------
/*
 * MATRIX TRANSPOSITION
 * It creates auxiliary variable 'res' of type Matrix, where are the rows of source matrix written
 * as the columns of result matrix 'res' = source^T.
 * Method returns pointer on transposed matrix to the matrix above which the method was called.
 */
      Matrix             * Matrix :: Transp      ( void ) const
 {
   Matrix * res = new Matrix ( m_Cols, m_Rows, true );
   
   for ( int i = 0 ; i < m_Rows ; i ++ )
      for ( int j = 0 ; j < m_Cols ; j ++ )
         res -> m_Data [ j ][ i ] = m_Data [ i ][ j ];
   
   return res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * MATRIX INVERSION
 * It creates a temporary matrix 'all' of the double size (it means matrix this|E) and stores
 * the data from source matrix '*this' to the left half. Right half is identity matrix, so on the
 * diagonal are the same ones and otherwise zeros. Than the matrix 'all' will be converted to
 * Upper triangular form, than to Lower triangular form and now is the result in the right half
 * (it means matrix E|this^-1). These data are stored in the matrix 'res' of the size like the
 * source matrix '*this'. The temporary matrix 'all' will be deleted and the method returns a
 * pointer to the result matrix 'res'.
 */
      Matrix             * Matrix :: Invers      ( void ) const
 {
   Matrix * all = new Matrix ( m_Rows, m_Cols * 2, true );
   Matrix * res = new Matrix ( m_Rows, m_Cols    , true );
   int i, j;
   
   for ( i = 0 ; i < m_Rows ; i ++ )
    {
      for ( j = 0 ; j < m_Cols * 2 ; j ++ )
         if ( j < m_Cols )
            all -> m_Data [ i ][ j ] = m_Data [ i ][ j ];
         else if ( i == j - m_Cols )
            all -> m_Data [ i ][ j ] = 1;
    }
   
   *all = all -> UppTriForm ();
   *all = all -> LowTriForm ();
   
   for ( i = 0 ; i < m_Rows ; i ++ )
      for ( j = 0 ; j < m_Cols ; j ++ )
         res -> m_Data [ i ][ j ] += all -> m_Data [ i ][ j + m_Cols ];
   
   delete all;
   return res;
 }
//--------------------------------------------------------------------------------------------------
/*
 * DETERMINANT OF MATRIX
 * First checks if the matrix is square shaped. If not, the determinant is equal to zero. Than it
 * creates a new temporary matrix 'src' which is a copy of source matrix '*this' converted into
 * the Upper triangular form and returns with self a number 'coefficient' which must be the
 * determinant multiplied at the end (it represents the changes performed during the GEM). It
 * multiplies the numbers on the diagonal and the 'coefficient'. If the resulting determinant is
 * a number very closed to the zero, returns zero. The temporary matrix 'src' will be deleted.
 */
      double               Matrix :: Determ      ( void ) const
 {
   double det = 1, coefficient = 0;
   int i, j;
   
   if ( m_Rows != m_Cols )
      return 0;
   
   Matrix * src = new Matrix ( * this );
   *src = src -> UppTriForm ( coefficient );
   
   for ( i = 0, j = 0 ; i < m_Rows ; i ++, j ++ )
      det *= src -> m_Data [ i ][ j ];
   det *= coefficient;

   /* (0.000001 - positive zero, -0.000001 - negative zero) */
   if ( det < 0.000001 && det > -0.000001 ) det = 0;
   
   delete src;
   return det;
 }
//--------------------------------------------------------------------------------------------------
/*
 * RANK OF MATRIX
 * It creates a temporary matrix 'src' which is a copy of source matrix '*this'. Than it will be
 * converted into the Upper triangular form and than into the Lower triangular form. Now there
 * are the ones on the non-zero rows and just count the sum of all these non-zero rows. The
 * temporary matrix 'src' will be deleted and the rank of matrix 'cnt' will be returned.
 */
      double               Matrix :: Rank        ( void ) const
 {
   int i, j, cnt = 0;
   
   Matrix * src = new Matrix ( * this );
   *src = src -> UppTriForm ();
   *src = src -> LowTriForm ();
   
   for ( i = 0 ; i < m_Rows ; i ++ )
    {
      for ( j = 0 ; j < m_Cols ; j ++ )
         if ( src -> m_Data [ i ][ j ] != 0 ) break;
      if ( j != m_Cols ) cnt ++;
    }
   
   delete src;
   return cnt;
 }
//--------------------------------------------------------------------------------------------------
/* Returns number of rows of *this instance of class Matrix */
      int       	         Matrix :: GetRows     ( void ) const
 {
   return m_Rows;
 }
//--------------------------------------------------------------------------------------------------
/* Returns number of columns of *this instance of class Matrix */
      int                  Matrix :: GetCols     ( void ) const
 {
   return m_Cols;   
 }
//--------------------------------------------------------------------------------------------------
/*
 * SETTING THE ELEMENTS INTO MATRIX
 * User can set arbitrarily element in the matrix and its value will be saved in the given
 * position. The numbering begins from the zeros, for example [0][0] and the entering ends
 * with pressing the key 'Q' by the end of input. 
 */
      void                 Matrix :: SetElems    ( void )
 {
   char   in1, in2, in3, in4, in5, choise;
   int    x, y;
   double val;
   
   cout << "Now you can fill the matrix with the elements you want:"     << endl
        << "Format : \"[x][y]=value C/Q\" (C for Continue, Q for quit )" << endl;
   
   while ( 1 )
    {
      /*      [     x     ]      [     y     ]      =    value    C/Q      */
      cin >> in1 >> x >> in2 >> in3 >> y >> in4 >> in5 >> val >> choise;
      
      if ( x >= m_Rows || y >= m_Cols )
       {
         cout << "The matrix is of size " << m_Rows << "x" << m_Cols << endl
              << "The positon [" << x << "][" << y << "] is not included in this matrix." << endl; 
       }
      else
       {
         m_Data [ x ][ y ] = val;
       }
      
      if ( choise == 'Q' ) break;
      else if ( choise == 'C' )
       {
         cout << "Next element:" << endl;
         continue;
       }
      else
       {
         cout << "Unknown choise, please continue with typing next element:" << endl;
         continue;
       }
    }
   
   return;
 }
//--------------------------------------------------------------------------------------------------
/*
 * SAVING THE MATRIX
 * Creates <@param fileName> output file contains data of matrix we want save and stores it into
 * the main folder. End of lines - '\n', Space between data - ' ', End of file - 'EOF sign'.
 */
      bool                 Matrix :: Save        ( const char * fileName ) const
 {
   ofstream outFile ( fileName );
   
   for ( int i = 0 ; i < m_Rows ; i ++ )
    {
      for ( int j = 0 ; j < m_Cols ; j ++ )
       {
         outFile << m_Data [ i ][ j ];
         if ( j != m_Cols - 1 )
            outFile . put ( ' ' );
       }
      if ( i != m_Rows - 1 )
         outFile . put ( '\n' );
    }
   
   outFile . close ();
   return true;
 }


